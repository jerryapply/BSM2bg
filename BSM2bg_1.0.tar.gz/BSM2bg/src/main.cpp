#include <RcppArmadillo.h>
#include <Rcpp.h>
using namespace Rcpp;
using namespace arma;
using namespace std;
// [[Rcpp::depends(RcppArmadillo)]]

arma :: vec rrinvgauss(int n, double mu, double lambda){
  
  arma ::vec random_vector(n);
  double z,y,x,u;
  if(mu > 1e6)
  { random_vector = pow(Rcpp::rnorm(1, 0, 1), -2);}
  else{
    for(int i=0; i<n; ++i){
      z=R::rnorm(0,1);
      y=z*z;
      x=mu+0.5*mu*mu*y/lambda - 0.5*(mu/lambda)*sqrt(4*mu*lambda*y+mu*mu*y*y);
      u=R::runif(0,1);
      if(u <= mu/(mu+x)){
        random_vector(i)=x;
      }else{
        random_vector(i)=mu*mu/x;
      };
    }
  }
  return(random_vector);
}


arma::vec reptest2(arma ::vec x, arma::vec y) {
  int n = y.size();
  arma::vec myvector(sum(y));
  int ind=0;
  for (int i=0; i < n; ++i) {
    int p = y[i];
    std::fill(myvector.begin()+ind, myvector.begin()+ind+p, x[i]);
    ind += p;
  }
  return myvector;
}

arma::vec rep(arma ::vec x, arma::vec y) {
  int n = y.size();
  arma::vec myvector(sum(y));
  int ind=0;
  for (int i=0; i < n; ++i) {
    int p = y[i];
    std::fill(myvector.begin()+ind, myvector.begin()+ind+p, x[i]);
    ind += p;
  }
  return myvector;
}

arma::mat tridiag(arma::vec upper, arma::vec lower, arma::vec main){
  int dim = main.n_elem;
  arma::mat tri_diag(dim, dim); 
  tri_diag = zeros(dim, dim);
  tri_diag.diag() = main;
  int k = upper.n_elem;
  for( int i=0; i<k; i++){
    tri_diag((i + 1), i) = lower(i);
    tri_diag(i, (i + 1)) = upper(i);
  }
  return(tri_diag);
}

arma::mat mvrnormArma(int n, arma::vec mu, arma::mat U) {
  int ncols = U.n_cols;
  arma::mat Y = arma::randn(n, ncols);
  return arma::repmat(mu, 1, n).t() + Y * U;
}

arma::vec backsolve_c(arma::mat U, arma::vec b){
  int n = b.n_elem;
  arma::vec x = zeros(n);
  for(int i = 0; i<n; i++)
  {
    x(n-1-i) = (b(n-1-i) - dot(U.row(n-1-i), x)) / U((n-1-i), (n-1-i));
  }
  return(x);
}


arma::vec forwardsolve_c(arma::mat U, arma::vec b){
  int n = b.n_elem;
  arma::vec x = zeros(n);
  for(int i = 0; i<n; i++)
  {
    x(i) = (b(i) - dot(U.row(i), x)) / U((i), (i));
  }
  return(x);
}

arma::vec iter_bgl_fast(vec beta, double sigma2, arma ::mat X, arma ::vec Y, double alpha,
                        double xi, arma::vec XTY, int n, int p, double lambda, 
                        arma::vec group_size)
{
  int k = group_size.n_elem;
  arma ::vec beta_l2(k);
  int start = 0;
  int  end;
  for(int i = 0; i < k; i++){
    end = start + group_size(i) - 1;
    vec beta_i;
    beta_i = beta.subvec(start, end);
    beta_l2(i) = sum(square(beta_i));
    start = start + group_size(i);
  }
  arma :: vec tau_inv(k);
  for(int i = 0; i < k; i++){
    double mu, betai;
    mu = sqrt(pow(lambda, 2) * sigma2 / beta_l2(i));
    betai = as_scalar(rrinvgauss(1, mu, pow(lambda, 2)));
    tau_inv(i) = betai;
  }
  arma :: vec tau_inv_f(p);
  tau_inv_f = reptest2(tau_inv, group_size);
  arma :: vec tau = 1 / tau_inv_f;
  arma ::vec u(p);
  arma ::vec v_norm(n);
  for(int i = 0; i < p; i++){
    u(i) = sqrt(tau(i)) * (R::rnorm(0,1) );
  }
  for(int i = 0; i < n; i++){
    v_norm(i) = R::rnorm(0, 1);
  }
  arma ::vec v(n);
  v = X * u + v_norm;
  arma ::mat mat_t;
  mat_t = arma::eye<arma::mat>(n,n) + X * diagmat(tau) * X.t();
  arma ::mat U =chol(mat_t);
  arma :: vec w(n);
  w = backsolve_c(U, forwardsolve_c(U.t(),  -v));
  
  arma ::vec beta_tilde;
  beta_tilde = X.t() * backsolve_c(U, forwardsolve_c(U.t(), Y));
  beta_tilde = tau % beta_tilde;
  double sigma2_new, part1, part2;
  part1 = sum(square(Y)) - sum(XTY % beta_tilde);
  part2 = R::rchisq(n + 2*alpha);
  sigma2_new = part1 / part2;
  arma ::vec beta_new(p);
  beta_new = beta_tilde + sqrt(sigma2_new) * (u + tau % (X.t() * w));
  
  arma::vec res((p + 1));
  res.subvec(0, (p-1)) = beta_new;
  res(p) = sigma2_new;
  return(res);
}

arma::vec iter_bfl_fast(vec beta, double sigma2, arma ::mat X, arma ::vec Y, double alpha,
                            double xi, arma::vec XTY, arma::mat XTX, int n, int p, 
                            double lambda1, double lambda2){
  arma::vec tau_inv(p);
  for(int i = 0; i < p; i++){
    double mu, betai;
    mu = sqrt(pow(lambda1, 2) * sigma2 / pow(beta(i), 2));
    betai = as_scalar(rrinvgauss(1, mu, pow(lambda1,2)));
    tau_inv(i) = betai;
  }
  arma :: vec omega_inv(p-1), beta_diff(p-1);
  beta_diff = beta.subvec(1, p-1) - beta.subvec(0, p-2);
  for(int i = 0; i <(p-1); i++)
  {
    double mu, betai;
    mu = sqrt(pow(lambda2, 2) * sigma2 / pow(beta_diff(i),2));
    betai = as_scalar(rrinvgauss(1, mu, pow(lambda2, 2)));
    omega_inv(i) = betai;
  }
  arma ::vec part1(p), part2(p);
  part1 = zeros(p);
  part2 = zeros(p);
  part1.subvec(0, (p-2)) = omega_inv;
  part2.subvec(1, (p-1)) = omega_inv;
  arma ::vec diag_omega = part1 + part2;
  arma ::vec diag_sum = tau_inv + diag_omega;
  arma ::mat inv_omega_tau =  tridiag((-1)*omega_inv, (-1)*omega_inv, diag_sum);
  arma ::mat A_tau_omega = XTX  + inv_omega_tau;
  arma ::mat U = chol(A_tau_omega);
  double rate, sigma2_new;
  rate = sum(square(Y))-as_scalar(XTY.t()*backsolve_c(U, forwardsolve_c(U.t(), XTY)))+2*xi;
  sigma2_new = rate / R::rchisq(n + 2*alpha);
  arma :: vec b_mean = backsolve_c(U, forwardsolve_c(U.t(), XTY));
  arma ::mat V(p,p);
  arma ::mat I = arma::eye<arma::mat>(p,p);
  for(int i = 0; i<p; i++){
    V.col(i) = backsolve_c(U, I.col(i));
  }
  arma :: mat beta_new = mvrnormArma(1, b_mean, sqrt(sigma2_new) * V.t()).t();
  arma::vec res((p + 1));
  res.subvec(0, (p-1)) = beta_new;
  res(p) = sigma2_new;
  return(res);
}  

arma::vec iter_bsgl_fast(vec beta, double sigma2, arma ::mat X, arma ::vec Y, double alpha,
                   double xi, arma::vec XTY, int n, int p, double lambda1, double lambda2,
                   arma::vec group_size)
{
  int k = group_size.n_elem;
  arma ::vec beta_l2(k);
  int start = 0;
  int  end;
  for(int i = 0; i < k; i++){
    end = start + group_size(i) - 1;
    vec beta_i;
    beta_i = beta.subvec(start, end);
    beta_l2(i) = sum(square(beta_i));
    start = start + group_size(i);
  }
  arma :: vec tau_inv(k);
  for(int i = 0; i < k; i++){
    double mu, betai;
    mu = sqrt(pow(lambda1, 2) * sigma2 / beta_l2(i));
    betai = as_scalar(rrinvgauss(1, mu, pow(lambda1, 2)));
    tau_inv(i) = betai;
  }
  arma :: vec gamma_inv(p);
  for(int i = 0; i < p; i ++)
  {
    double mu, betai;
    mu = sqrt(pow(lambda2, 2) * sigma2 / pow(beta(i),2));
    betai = as_scalar(rrinvgauss(1, mu, pow(lambda2, 2)));
    gamma_inv(i) = betai;
  }
  arma :: vec tau_inv_f(p);
  tau_inv_f = reptest2(tau_inv, group_size);
  arma :: vec tau_gamma = 1 / (tau_inv_f + gamma_inv);
  arma ::vec u(p);
  arma ::vec v_norm(n);
  for(int i = 0; i < p; i++){
    u(i) = sqrt(tau_gamma(i)) * (R::rnorm(0,1) );
  }
  for(int i = 0; i < n; i++){
    v_norm(i) = R::rnorm(0, 1);
  }
  arma ::vec v(n);
  v = X * u + v_norm;
  arma ::mat mat_t;
  mat_t = arma::eye<arma::mat>(n,n) + X * diagmat(tau_gamma) * X.t();
  arma::vec eigval = svd(mat_t);
  arma ::vec beta_tilde;
  arma :: vec w(n);
  if(eigval.min() > 0)
  {
  arma ::mat U = chol(mat_t);
  w = backsolve_c(U, forwardsolve_c(U.t(),  -v));
  beta_tilde = X.t() * backsolve_c(U, forwardsolve_c(U.t(), Y));
  }
  else
  {
   arma :: mat inv_t(n, n);
   arma :: mat U;
   arma :: vec s;
   arma :: mat V;
   arma :: svd(U, s, V, mat_t);
   inv_t = V * diagmat(1/s) * U.t();
   w = inv_t * (- v);
   beta_tilde = X.t() * (inv_t * Y);
  }
  beta_tilde = tau_gamma % beta_tilde;
  double sigma2_new, part1, part2;
  part1 = sum(square(Y)) - sum(XTY % beta_tilde);
  part2 = R::rchisq(n + 2*alpha);
  sigma2_new = part1 / part2;
  arma ::vec beta_new(p);
  beta_new = beta_tilde + sqrt(sigma2_new) * (u + tau_gamma % (X.t() * w));
  
  arma::vec res((p + 1));
  res.subvec(0, (p-1)) = beta_new;
  res(p) = sigma2_new;
  return(res);
}

// [[Rcpp::export]]
List bsgl(arma::mat X, arma::vec Y, arma::vec group_size, arma::vec beta, 
         double sigma2, double lambda1 =1, double lambda2 = 1, double alpha = 0, 
         double xi = 0, int K = 10000){
  arma ::vec XTY = X.t() * Y;
  int n = X.n_rows;
  int p = X.n_cols;
  arma::mat betas(K, p);
  arma::vec sigma2s(K);
  arma::vec iter;
  for(int i = 0; i<K; i++){
    iter = iter_bsgl_fast(beta, sigma2, X, Y, alpha, xi, XTY, n, p, lambda1, lambda2, group_size);
    beta = iter.subvec(0, (p-1));
    sigma2 = iter(p);
    sigma2s(i) = sigma2;
    betas.row(i) = beta.t();
  }
  List chains = List::create(Rcpp ::Named("betas") = betas, 
                             Rcpp ::Named("sigma2s")= sigma2s);
  return(chains);
}

// [[Rcpp::export]]
List bfl(arma::mat X, arma::vec Y, arma::vec beta, double sigma2, double lambda1 =1, 
                  double lambda2 = 1, double alpha = 0, double xi = 0, int K = 20000){
  arma ::vec XTY = X.t() * Y;
  arma ::mat XTX = X.t() * X;
  int n = X.n_rows;
  int p = X.n_cols;
  arma::mat betas(K, p);
  arma::vec sigma2s(K);
  arma::vec iter;
  for(int i = 0; i<K; i++){
    iter = iter_bfl_fast(beta, sigma2, X, Y, alpha, xi, XTY, XTX, n, p, lambda1, lambda2);
    beta = iter.subvec(0, (p-1));
    sigma2 = iter(p);
    sigma2s(i) = sigma2;
    betas.row(i) = beta.t();
  }
  List chains = List::create(Rcpp ::Named("betas") = betas, 
                             Rcpp ::Named("sigma2s")= sigma2s);
  return(chains);
}

// [[Rcpp::export]]
List bgl(arma::mat X, arma::vec Y, arma::vec group_size, arma::vec beta, 
         double sigma2, double lambda =1, double alpha = 0, double xi = 0,
         int K = 10000){
  arma ::vec XTY = X.t() * Y;
  int n = X.n_rows;
  int p = X.n_cols;
  arma::mat betas(K, p);
  arma::vec sigma2s(K);
  arma::vec iter;
  for(int i = 0; i<K; i++){
    iter = iter_bgl_fast(beta, sigma2, X, Y, alpha, xi, XTY, n, p, lambda, group_size);
    beta = iter.subvec(0, (p-1));
    sigma2 = iter(p);
    sigma2s(i) = sigma2;
    betas.row(i) = beta.t();
  }
  List chains = List::create(Rcpp ::Named("betas") = betas, 
                             Rcpp ::Named("sigma2s")= sigma2s);
  return(chains);
}
